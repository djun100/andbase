package com.andbase.demo.model;

public class ImageInfo {

	private int height;
	private String url = "";

	public int getWidth() {
		return 300;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

}
